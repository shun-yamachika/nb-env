/*
file: scheduler.h
author: Julio Oliveira and Coen van Leeuwen, TNO

Declaratino of a base interface for the scheduler.
*/

#ifndef INCLUDED_SCHEDULER_
#define INCLUDED_SCHEDULER_

#include "scheduleruserinterface.h"
#include "schedulerinspectorinterface.h"

namespace dynaa {
class Scheduler : public SchedulerUserInterface, public SchedulerInspectorInterface {
};
}

#endif
