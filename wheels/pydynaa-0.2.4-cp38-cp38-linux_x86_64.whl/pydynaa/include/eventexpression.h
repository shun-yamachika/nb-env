/*
file: eventexpression.h
authors: Julio Oliveira, Rob Knegjens

Definition of the EventExpression class
*/

#ifndef INCLUDED_EVENT_EXPRESSION_
#define INCLUDED_EVENT_EXPRESSION_

#include "event.h"
#include "eventtype.h"
#include "dynaatypes.h"
#include <memory>
#include <tuple>
#include <vector>

namespace dynaa {

// Forward declaration for friendship
class DefaultHandlerRegistry;  

enum EventExpressionType {Atomic, AND, OR};

/**
 * Core class for an event expression
 *
 * An event expression is a boolean expression on one or more event triggering conditions.
 *
 * An event triggering condition is a triplet (source, type, id) indicating a condition
 * to be satisfied by an event.  If events are issued that satisfy a tripplet of the expression,
 * the complete expression is evaluated.  Evaluating an event expression to true causes a given
 * callback std::function to be invoked.
 *
 * The idea behind event expressions is to be able to wait for combinations of event conditions.
 * Examples:
 *
 *  -  Wait until both occur:  "any event coming from source_A"  AND  "any event coming from source_B".
 *  -  Wait until any occur:  "any event of type T1" OR "any event of type T2 coming from source_C".
 */

class EventExpression : public std::enable_shared_from_this<EventExpression> {

    // Friendship needed to set the private trigger event; TODO set differently?
    friend class DefaultHandlerRegistry;

private:

    const EventSource m_entity;
    const EventType m_evType;  // NOTE could also manage ownership with smart pointer for efficiency
    const EventID m_id;

    // replaced by m_trigger_event != NULL
    //bool m_value;

    EventExpressionType m_type;

    // Sub-expressions if applicable
    std::shared_ptr<EventExpression> m_firstTerm;
    std::shared_ptr<EventExpression> m_secondTerm;

    // Trigger event
    std::unique_ptr<Event> m_trigger_event;
    SimTime m_trigger_timestamp;

public:
    /**
     * Constructor for EventExpression.
     *
     * Using this consctructor creates always a basic (or atomic) event expression.
     *
     * This atomic EventExpression may be combined with others by means of boolean operators
     * && and || to create more complex EventExpressions.
     *
     * @param entity
     *      An EventSource from where the triggering event should come from, use Event::ANY_SOURCE for a wildcard on the source.
     * @param evType
     *      An EventType for the event that should trigger this event expression, use Event::ANY_TYPE for a wildcard on the type.
     * @param id
     *      An identifier for the specific event that should trigger this event expression, use Event::ANY_ID for a wildcard on the type.
     */
    EventExpression(EventSource entity, EventType evType, EventID id) :
            m_entity(entity),
            m_evType(evType),
            m_id(id),
            m_type(Atomic) {}

    /**
     * Default Constructor .
     */
    EventExpression() : EventExpression(Event::ANY_SOURCE, Event::ANY_TYPE, Event::ANY_ID) {} //Constructor

    /**
     * Copy constructor.
     *
     * Ensures deep copy of child expressions. Does not copy triggered events.
     */
    EventExpression(const EventExpression &evExpression) ;

    /**
     * Default destructor
     *
     * Higher level expressions, such as combined AND and OR expressions
     * own a copy of their internal expressions.  They are responsible for
     * releasing it.
     *
     * Note that higher level expressions hold a shared pointer to its internal
     * expressions, which in turn can be shared with other parties.  Destroying
     * a higher level expression releases this pointer.  If the expression is
     * the only one holding the pointer, the sub-expressions are also destroyed.
     * If not, it is preserved to whoever else is holding it.
     *
     */
    ~EventExpression() ;

    /**
     * Retrieve event type of an atomic expression.
     *
     * If this is not an atomic expression, then ANY_TYPE is returned.
     *
     * @return EventType.
     */
    const EventType& atomicEventType() const;

    /**
     * Retrieve event ID of an atomic expression.
     *
     * If this is not an atomic expression, then ANY_ID is returned.
     *
     * @return EventID.
     */
    EventID atomicEventID() const;

    /**
     * Retrieve event source (entity) of an atomic expression.
     *
     * If this is not an atomic expression, then ANY_SOURCE is returned.
     *
     * @return EventSource.
     */
    EventSource atomicEventSource() const;

    /**
     * Retrieves the type of this EventExpression
     *
     * Type of an EventExpression can be Atomic, AND or OR.
     * Type of an EventExpression is defined by the type EventExpressionType.
     *
     * @return EventExpressionType indicating the type of this EventExpression: Atomic, AND, or OR
     *
     * @see EventExpressionType
     */
    EventExpressionType type() const;

    /**
     * Retrieves the actual logical value of this expression
     *
     * The value of an Atomic expression is its internal value which is true if
     * the expression has be at least once triggered by an issed event.
     *
     * The value of an AND or OR expression is a boolean AND or a boolean OR of
     * the values of its terms (expressions).
     */
    bool value() const;

    /**
     * The event that triggered this event expression, or a null pointer 
     * if it was not triggered.
     *
     * @return pointer to triggered Event or a null pointer.
     */
    std::unique_ptr<Event> triggeredEvent() const;

    /**
     * Returns the first term of this expression as a shared pointer.
     *
     * AND and OR expression are binary expressions.  In this case the
     * first term is returned. E.g. A && B, returns A.
     *
     * Atomic expressions is a unary expression.  In this case we consider
     * that the first, and the second term are the expression itself.  Thus,
     * retrieving the first term of an atomic expression, returns itself.
     *
     * @return a smart pointer to the first term of this expression.
     */
    const std::shared_ptr<EventExpression> firstTermAsPtr();

    /**
     * Returns the first term of this expression.
     *
     * AND and OR expression are binary expressions.  In this case the
     * first term is returned. E.g. A && B, returns A.
     *
     * Atomic expressions is a unary expression.  In this case we consider
     * that the first, and the second term are the expression itself.  Thus,
     * retrieving the first term of an atomic expression, returns itself.
     *
     * @return the first term of this expression.
     */
    const EventExpression& firstTerm() const;

    /**
     * Returns the second term of this expression.
     *
     * AND and OR expression are binary expressions.  In this case the
     * second term is returned. E.g. A && B, returns B.
     *
     * Atomic expressions is a unary expression.  In this case we consider
     * that the first, and the second term are the expression itself.  Thus,
     * retrieving the second term of an atomic expression, returns itself.
     *
     * @return a smart pointer to the second term of this expression.
     */
    const EventExpression& secondTerm() const;

    /**
     * Returns the second term of this expression.
     *
     * AND and OR expression are binary expressions.  In this case the
     * second term is returned. E.g. A && B, returns B.
     *
     * Atomic expressions is a unary expression.  In this case we consider
     * that the first, and the second term are the expression itself.  Thus,
     * retrieving the second term of an atomic expression, returns itself.
     *
     * @return a smart pointer to the second term of this expression.
     */
    const std::shared_ptr<EventExpression> secondTermAsPtr();

    /**
     * Reset the event expression by setting all its atomic expressions
     * to not triggered.
     *
     * Note we don't use 'reset' here to avoid mistakes and confusion
     * with reseting the shared poitner holding an event expression.
     */
    void reprime();

    /**
     * Utility print std::function
     */
    friend std::ostream& operator<<(std::ostream &strm, const EventExpression &expression);
    friend std::ostream& operator<<(std::ostream &strm, const std::shared_ptr<EventExpression>&  expression);

    /**
     * Defines && operator for event expressions.
     *
     * Produces always an AND EventExpression with this as the first term and second as the second term.
     */
    EventExpression operator&&(const EventExpression& second);
    // Same operator, created to import in Cython (operator&& is not supported in cython)
    //std::shared_ptr<EventExpression> operatorAnd(const std::shared_ptr<EventExpression>& second);
    std::shared_ptr<EventExpression> logicalAnd(const std::shared_ptr<EventExpression>& second);

    /**
     * Defines || operator for event expressions.
     *
     * Produces always an OR EventExpression with this as the first term and second as the second term.
     */
    EventExpression operator||(const EventExpression& second);
    // Same operator, created to import in Cython (operator&& is not supported in cython)
    std::shared_ptr<EventExpression> logicalOr(const std::shared_ptr<EventExpression>& second);

    /**
     * Defines an equality operator for event expressions.
     *
     * Default operator does not work, because there is no deep comparison.
     */
    bool operator==(const EventExpression& second) const;
    /**
     * Defines an inequality operator for event expressions.
     */
    bool operator!=(const EventExpression& second) const;

    /**
     * Creates a triggered atomic EventExpression wrapping an event.
     *
     * Assumes the event occured on the timeline.
     *
     * @param event
     *      Event to create event epxression for.
     *
     */
    static std::shared_ptr<EventExpression> wrapTriggeredEvent(Event event);
};

/**
 * Overloads the << operator
 */
std::ostream& operator<<(std::ostream &strm, const EventExpression &expression);
std::ostream& operator<<(std::ostream &strm, const std::shared_ptr<EventExpression>& expression);
}

/**
 * DISCUSSIONS AND DECISIONS
 *
 * Redesign of EventExpresion --------------
 *
 * 1) EventExpression is no longer an Entity and can no longer 'wait'.
 *    To wait on an event expression the waitOnce() method of an existing entity should
 *    be used.
 *
 * 2) EventExpression no longer holds a callback.
 *    An EventExpressionHandler holds the callback to be called when an event expression
 *    is triggered.
 *
 * Design of EventExpression --------------- NOTE: this is old
 *
 * 1) EventExpression is an Entity.
 *    One can activate an event expression. From this moment on, the expression will call a callback the first time it is triggered by an event.
 *    Notice that an event expression may contain other event expressions -- each of which will cause a re-evaluation of the whole expression tree in cascade.
 *
 * 2) Use EventExpressions creating and holding them in std::shared_ptr or weak_ptr.
 *
 */

#endif
