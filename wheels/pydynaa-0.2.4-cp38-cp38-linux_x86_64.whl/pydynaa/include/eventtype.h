/*
file: eventtype.h
authors: Julio Oliveira, Coen van Leeuwen

Definition of the EventType class
*/

#ifndef INCLUDED_EVENTTYPE_
#define INCLUDED_EVENTTYPE_

#include <string>
#include <algorithm>
#include <iostream>

namespace dynaa {
/**
 * Core class for a simulation event type
 *
 * An event type defines a certain sort of event.
 *
 * Events types are initialized with a name and descriptor, which are mainly
 * intended to be used for documentation.  On creation of an event type it also
 * receives automatically (not in users control) a type number (long).  This number is
 * unique for each event type and can be used for efficient identification of types.
 */
class EventType {

private:
    static long m_typeSequenceNumber;

    const long m_id;

    const std::string m_name;

    const std::string m_description;

public:
    /**
     * Default constructor
     *
     * Try to use the named (described) constructor.  It prints out better in the log.
     *
     * We provide a default constructor because giving a name or description is not obligatory.  Also, it allows to make things like:
     *
     * >> EventType firstType = EventType("example_type","Just an example type");
     * >> EventType myEventType;  // Creates a different type !!!!
     * >> assert(firstType != myEventType);
     *
     */
    EventType() : m_id(EventType::m_typeSequenceNumber++), m_name(""), m_description("") {}

    /**
     * Constructor
     *
     * Builds a new EventType with the given name and description.
     *
     * IMPORTANT:
     * The name and description of an EventType are just a helper, they do not define the type per se.
     * The type definition is defined the the id, which is acquired when creating a type.
     * This way, for example, two types can have the same name and description and yet be of another type.
     *
     * @param name
     *            the name of this event type
     * @param description
     *            the description of this event type
     */
    EventType(const std::string& name, const std::string& description) :
        m_id(EventType::m_typeSequenceNumber++),
        m_name(name),
        m_description(description) {};

    /**
     * Copy constructor
     *
     * Represents exactly the same event type
     */
    EventType(const EventType& eventType) :
        m_id(eventType.m_id),
        m_name(eventType.m_name),
        m_description(eventType.m_description) {};

    /**
     * Returns the name given to this event type
     *
     * @return the name given to this event type
     */
    std::string name() const;

    /**
     * Returns a textual description of this event type for human interpretation.
     *
     * @return a textual description of this event type
     */
    std::string description() const;

    /**
     * Returns the unique identifier given to this event type
     *
     * @return a unique identifier given to this event type
     */
    long id() const;

    /**
     * The equality operator for this event type
     */
    bool operator==(const EventType &other) const;

    /**
     * The inequality operator for this event type
     */
    bool operator!=(const EventType &other) const;

    /**
     * the streaming operator  for this event type
     */
    friend std::ostream& operator<<(std::ostream &strm, const EventType &ev);

    /**
     * Factory method.
     *
     * DEPRECATED: In process of being deprecated if no needed.  Under analysis for deprecation
     *
     * Produces an event type.  Basically use that to initialize static members of entities that issues this
     * type of event.
     *
     *  The create event type is unique.  Name and description are only for human identification.
     *
     * Types with the same name and description are still different if created separatelly.  Use the equality
     * operator to determine equality.
     *
     * @param name a name for this event type
     * @param description a textual description of this event type
     * @return a new event type
     */
    static EventType create(const std::string& name, const std::string& description);
};

/**
 * Overloads the << operator
 */
std::ostream& operator<<(std::ostream &strm, const EventType &ev);
}

/**
 * DISCUSSIONS AND DECISIONS
 *
 * Design of EventType
 *
 * 1) EventType is immutable.
 *
 * Reason for that is that you can create and make copies of a certain event type in a very safe and efficient way. Recommendation is that EventType objects are not create by new, but they are referred to or copied.
 *
 * 2) Use short names and description.
 * Name and description of an event type are basically meant for printing user information in loggers or debug
 * cycles.  Thus, keep then short, meaninful, and expressive.
 */

#endif
