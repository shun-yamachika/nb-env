/*
file: dynaatypes.h
author: Coen van Leeuwen, TNO
date: 01-08-2011
*/

#ifndef INCLUDED_DYNAATYPES_
#define INCLUDED_DYNAATYPES_

#include <stdio.h>

namespace dynaa {
class Timeline;

typedef double SimTime;
typedef long SourceUID;

}

#endif
