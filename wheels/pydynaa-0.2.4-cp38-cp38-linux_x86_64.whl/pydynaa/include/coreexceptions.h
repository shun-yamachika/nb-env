/**
 * File coreexceptions.h
 */

#ifndef INCLUDED_COREEXCEPTIONS_
#define INCLUDED_COREEXCEPTIONS_

#include <stdexcept>

namespace dynaa {

/**
 * Exception type for invalid timepoint usage in the core
 *
 * This exception is issued by the DynAA core when an invalid timepoint is used in the core.
 *
 * Typical misuses or occurrences of invalid timepoints are:
 *
 * - Scheduling events at a time before the current time
 * - Scheduling events after a negative time delay
 *
 */
class InvalidTimePointException: public std::invalid_argument {
public:
    InvalidTimePointException() : std::invalid_argument("Invalid timepoint was used in the Core.") {}
};

/**
 * Exception type for stopped simulation
 *
 * This exception is issued by the DynAA core when the user tries to run a stopped simulation.
 *
 * Stopped is the last state of a simulation and cannot be modified anymore.  Simulations run up to
 * a final given time, or up to the instant where there are no more future events.  In both cases,
 * the simulation goes to an Idle state.  Idle states can be resumed.
 *
 * If for some reason a simulation is Stopped (user request, or internal error) there is no way to resume it.
 *
 */
class SimulationStoppedException: public std::runtime_error {
public:
    SimulationStoppedException(): std::runtime_error("Trying to run a stopped simulation.") {}
};


/**
 * Exception type for interrrupted simulation
 *
 * This exception is issued by the DynAA core when the simulation is in Running state and it is interrupted.
 *
 * Interruptions can happen by the user or by an internal error.  After an interruption, the simulation engine
 * is set to idle, and the simulation can be resumed.
 *
 *
 */
class SimulationInterruptedException: public std::runtime_error {
public:
    SimulationInterruptedException(): std::runtime_error("Simulation stopped before time.") {}
};

/**
 * Exception type for detection of invalid event sources
 *
 * This exception is issued by the DynAA core when the user tries to retrieve a non-existing source from an event.
 *
 * This exception is mainly caused by an event whose source was already deleted from the memory.
 *
 */
class InvalidEventSourceException: public std::runtime_error {
public:
    InvalidEventSourceException():
        std::runtime_error("Source of event does not exist. Check the lifetime management of simulation entities.") {}
};

/**
* EventHandlers have (smart)pointers for the callback functions and when needed to the objects that own such callbacks -- for example, a method of an instance.
*
* If the callback function cannot be invoked safely, this exception is thrown.
* Example of failing conditions:
*   - Instance holding the callback function does not exist anymore;
*   - Objects declared as 'guard' for the handler do not exist anymore;
*/
class InvalidHandler: public std::exception {
    virtual const char* what() const noexcept {
        return "Invalid handler callback - cannot be called safely.";
    }
};

/**
 * EventHandlers have a priority level that defaults to 5 and must be in the
 * range between 1 and 10.  Trying to create an event handler with priority
 * outside this range of values produces this exception.
 */
class InvalidEventHandlerPriority: public std::runtime_error {
public:
    InvalidEventHandlerPriority():
        std::runtime_error("priority of EventHandler must be in range [1,10].") {}
};


}

#endif
