#ifndef INCLUDED_CYTHON_ENTITY_
#define INCLUDED_CYTHON_ENTITY_
/* Definition of a modified Entity class that plays nicely with Cython.
 */

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include "eventhandler.h"
#include "expressionhandler.h"
#include "eventexpression.h"
#include <memory>
#include <vector>

namespace dynaa {
/**
 * Wrapper class for Entity class that is compatible with Cython
 *
 * Wraps the Entity class to give public access to protected methods for testing
 */
class CyEntity : public Entity {

private:
    PyObject* m_pyobj = NULL;

public:
    CyEntity() : Entity() {};

    CyEntity(PyObject* pyEntity) : Entity() {
        m_pyobj = pyEntity;
    };

    PyObject* pyobj() const {
        if (m_pyobj != NULL && Py_REFCNT(m_pyobj) > 0) {
            return m_pyobj;
        } else {
            return NULL;
        }
    };

    std::shared_ptr<Event> scheduleNow(const std::shared_ptr<EventType>& evType) {
        return std::make_shared<Event>(Event(Entity::scheduleNow(evType)));
    };
    std::shared_ptr<Event> scheduleAfter(SimTime interval, const std::shared_ptr<EventType>& evType) {
        return std::make_shared<Event>(Event(Entity::scheduleAfter(interval, evType)));
    };
    std::shared_ptr<Event> scheduleAt(SimTime instant, const std::shared_ptr<EventType>& evType) {
        return std::make_shared<Event>(Event(Entity::scheduleAt(instant, evType)));
    };

    // wait
    void wait(std::shared_ptr<EventHandler> eventHandler, const EventSource entity,
              const EventType & eventType, const EventID eventID) const {
        Entity::wait(eventHandler, entity, eventType, eventID);
    };
    void wait(std::shared_ptr<EventHandler> eventHandler,
              const EventType & eventType, const EventID eventID) const {
        Entity::wait(eventHandler, eventType, eventID);
    };
    void wait(std::shared_ptr<ExpressionHandler> expressionHandler, std::shared_ptr<EventExpression> eventExpression) {
        Entity::wait(expressionHandler, eventExpression);
    };

    // waitOnce
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const EventSource entity,
                  const EventType & eventType, const EventID eventID) const {
        Entity::waitOnce(eventHandler, entity, eventType, eventID);
    };
    void waitOnce(std::shared_ptr<EventHandler> eventHandler,
                  const EventType & eventType, const EventID eventID) const {
        Entity::waitOnce(eventHandler, eventType, eventID);
    };
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const Event & event) const {
        Entity::waitOnce(eventHandler, event);
    };
    void waitOnce(std::shared_ptr<ExpressionHandler> expressionHandler, std::shared_ptr<EventExpression> eventExpression) {
        Entity::waitOnce(expressionHandler, eventExpression);
    };

    // dismiss
    void dismiss(std::shared_ptr<EventHandler> eventHandler, const EventSource entity,
                 const EventType & eventType, const EventID eventID) {
        Entity::dismiss(eventHandler, entity, eventType, eventID);
    };
    void dismiss(std::shared_ptr<EventHandler> eventHandler,
                 const EventType & eventType, const EventID eventID) {
        Entity::dismiss(eventHandler, eventType, eventID);
    };
    void dismiss(std::shared_ptr<EventHandler> eventHandler, const Event & event) {
        Entity::dismiss(eventHandler, event);
    };
    void dismiss(std::shared_ptr<ExpressionHandler> expressionHandler, std::shared_ptr<EventExpression> eventExpression) {
        Entity::dismiss(expressionHandler, eventExpression);
    };
    void dismiss(std::shared_ptr<ExpressionHandler> expressionHandler) {
        Entity::dismiss(expressionHandler);
    };

};


void add_to_ptr_vector(std::vector<std::weak_ptr<Entity>> &ptr_vector, std::shared_ptr<CyEntity> toAdd) {
    ptr_vector.push_back(toAdd);
}

}
#endif
