/**
 * File handlerregistrationinterface.h
*/

#ifndef INCLUDED_HANDLERREGISTRATIONINTERFACE_
#define INCLUDED_HANDLERREGISTRATIONINTERFACE_

#include "eventhandler.h"
#include "eventtype.h"
#include <memory>

namespace dynaa {

/**
 * HandlerRegistryInterface
 *
 *
 */
class HandlerRegistrationInterface {

public:
    /**
     * Register an event handler as an observer for events from a certain
     * entity, and of a certain type, and with a certain id.
     *
     * @param eventHandler
     *            the event handler to be registered, in order to have it run
     *            any time an event occurs that matches the given arguments
     * @param entity
     *            the source of the events to listen to (can be
     *            {@link #ANY_ENTITY})
     * @param eventType
     *            the type of the events to listen to (can be {@link #ANY_TYPE})
     * @param id
     *            the id of the events to listen to. (can be {@link #ANY_ID})
     *
     */
    virtual void registerHandler(std::shared_ptr<EventHandler> eventHandler, const EventSource entity,
                                 const EventType &eventType,
                                 const EventID id, bool once) = 0;

    /**
     * Unregister an event handler from observing events from a certain entity,
     * and of a certain type, and with a certain id.
     *
     * @param eventHandler
     *            the event handler to be unregistered
     * @param entity
     *            the source of events (can be {@link #ANY_ENTITY})
     * @param eventType
     *            the type of events (can be {@link #ANY_TYPE})
     * @param id
     *            the id of the event (can be {@link #ANY_ID})
     */
    virtual void unregisterHandler(std::shared_ptr<EventHandler> eventHandler, const EventSource entity,
                                   const EventType &eventType,
                                   long id) = 0;

    /**
     * Register an expression handler as an observer for event expressions
     *
     * If the expression handler has a higher priority than existing expression handlers
     * waiting on this expression, the higher priority is adoped by the atomic expression
     * handlers of the event expression. The handlers themselves will still be called
     * in the order of their priority.
     *
     * If a registered event expression is triggered, all of the handlers registered to it have their
     * callbacks executed in order of priority, and are passed the triggered event expression.
     * Single shot handlers are removed from the set, and if any continuous handlers (once=false) remain,
     * the event expression is reset ("reprimed") and allowed to trigger again.
     *
     * @param expressionHandler
     *            the expression handler to be registered, in order to have it run
     *            any for an event expression
     * @param evExptr
     *            the event expression to listen to
     * @param once
     *            whether to only wait once for the expression to trigger.
     * @param reprime
     *            whether to reset the event expression. Default is true.
     *
     */
    virtual void registerHandler(std::shared_ptr<ExpressionHandler> expressionHandler,
                                 std::shared_ptr<EventExpression> evExpr, bool once, bool reprime=true) = 0;

    /**
     * Unregister an event handler from observing events from a certain entity,
     * and of a certain type, and with a certain id.
     *
     * @param expressionHandler
     *            the expression handler to be unregistered
     * @param evExptr
     *            the event expression to unregister the handler for
     *
     */
    virtual void unregisterHandler(const std::shared_ptr<ExpressionHandler>& expressionHandler,
                                   const std::shared_ptr<EventExpression>& evExpr) = 0;

    /**
     * Constructors, virtual destructor and assignment operator.
     */
    HandlerRegistrationInterface() = default;
    HandlerRegistrationInterface(const HandlerRegistrationInterface&) = default;
    HandlerRegistrationInterface(HandlerRegistrationInterface&&) = default;
    virtual ~HandlerRegistrationInterface() = default;
    HandlerRegistrationInterface& operator=(const HandlerRegistrationInterface&) = default;
    HandlerRegistrationInterface& operator=(HandlerRegistrationInterface&&) noexcept = default;
};
}

#endif
