/**
 * File handlerqueryinterface.h
 *
 */
#ifndef INCLUDED_HANDLERQUERYINTERFACE_
#define INCLUDED_HANDLERQUERYINTERFACE_

#include "event.h"
#include "eventhandler.h"
#include "expressionhandler.h"
#include "eventexpression.h"
#include <set>
#include <map>
#include <unordered_set>
#include <memory>

namespace dynaa {

template <typename T>
struct RegisteredHandler {
    RegisteredHandler(std::shared_ptr<T> the_handler, bool set_once=true) :
            handler(the_handler), once(set_once) {}
    RegisteredHandler(const RegisteredHandler<T>& other) :
            handler(other.handler), once(other.once) {}

    std::shared_ptr<T> handler;
    mutable bool once;
    bool operator< (const RegisteredHandler<T>& other) const {
        if (handler && other.handler)
            return *handler < *(other.handler);
        return false;
    }
};

typedef std::set<RegisteredHandler<EventHandler>> HandlerSet;
typedef std::set<RegisteredHandler<ExpressionHandler>> ExpressionHandlerSet;

/**
 * HandlerQueryInterface
 */
class HandlerQueryInterface {

public:
    /**
     * Get a set of all the event handlers of the given event. This would
     * include all handlers that implicitly should be called when they have
     * generic (i.e. when they listen to all events of a specific type)
     *
     * @param event
     *            an Event of which all handlers are requested
     * @return a collection of EventHandlers
     */
    // TODO this method should be 'const', however, it currently also takes care of cleaning up
    // single-shot handlers. That responsibility should be moved to another (non-query) method
    virtual HandlerSet getEventHandlersOf(const Event &event) = 0;

    /**
     * Get a set of all the expression handlers of the given event expression.
     *
     * @param event expression
     *            an event expression of which all handlers are requested
     * @return a collection of ExpressionHandlers
     */
    virtual ExpressionHandlerSet getExpressionHandlersOf(const std::shared_ptr<EventExpression>& evExpr) const = 0;

    /*
     * Retrieves the number of event handlers currently registered.
     *
     * @return an int specifying the number of event handlers registered.
     */
    virtual long int getNumberOfHandlers() const = 0;

    /**
     * Constructors, virtual destructor and assignment operator.
     */
    HandlerQueryInterface() = default;
    HandlerQueryInterface(const HandlerQueryInterface&) = default;
    HandlerQueryInterface(HandlerQueryInterface&&) = default;
    virtual ~HandlerQueryInterface() = default;
    HandlerQueryInterface& operator=(const HandlerQueryInterface&) = default;
    HandlerQueryInterface& operator=(HandlerQueryInterface&&) noexcept = default;

};
}

#endif
