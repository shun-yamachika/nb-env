/*
file: scheduleruserinterface.h
author: Julio Oliveira, Coen van Leeuwen

Scheduler user interface
*/

#ifndef INCLUDED_SCHEDULERUSERINTERFACE_
#define INCLUDED_SCHEDULERUSERINTERFACE_

#include <vector>

#include "dynaatypes.h"


namespace dynaa {
/**
* SchedulerUserInterface is an interface for users of the DynAA simulator scheduler.
* It provides a restricted (user) view for the scheduler, which allows to schedule
* events in the simulator.
*
* For the design of DynAA, it means that only Entities should be able to use this interface,
* as only Entities should be able to schedule and react to Events.
*
*/
class SchedulerUserInterface {
public:
    /**
     * Schedule an event to occur after some time from now.
     *
     * @param interval
     *            A double specifying the interval in time at which the event is
     *            scheduled
     * @param event
     *            The event that is scheduled after interval for now
     * @throws InvalidTimepointException
     *              Issued if interval passed is negative
     */
    virtual void scheduleAfter(const SimTime interval, const Event event) = 0;

    /**
     * Schedule an event to occur at a specific point in time.
     *
     * @param timepoint
     *            A double specifying the point in time at which the event is
     *            scheduled
     *
     * @param event
     *            The event that is scheduled at timepoint
     * @throws InvalidTimepointException
     *            Issued if timepoint is behind the current simulation time
     */
    virtual void scheduleAt(const SimTime timepoint, const Event event) = 0;

    /**
     * Schedule an event to occur now.
     *
     * @param event
     *            The event that is scheduled now.
     */
    virtual void scheduleNow(const Event event) = 0;

    /**
     * Unschedule an event from the timeline.
     *
     * This function removes the event from the timeline if it exists and was
     * scheduled to some instant in the simulation future.  If these conditions
     * are not met, no modifications occur to the timeline (guaranteed).
     *
     * If no events remain in the timeline instant after removal, the instant(key)
     * is removed from the timeline as well.
     *
     * @param event
     *          The event to be unscheduled.
     */
    virtual void unschedule(const Event event) = 0;

    /**
     * Constructors, virtual destructor and assignment operator.
     */
    SchedulerUserInterface() = default;
    SchedulerUserInterface(const SchedulerUserInterface&) = default;
    SchedulerUserInterface(SchedulerUserInterface&&) = default;
    virtual ~SchedulerUserInterface() = default;
    SchedulerUserInterface& operator=(const SchedulerUserInterface&) = default;
    SchedulerUserInterface& operator=(SchedulerUserInterface&&) noexcept = default;
};
}

#endif
