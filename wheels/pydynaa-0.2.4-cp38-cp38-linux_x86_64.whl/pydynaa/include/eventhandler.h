/**
 * File eventhandler.h
 */
#ifndef INCLUDED_EVENTHANDLER_
#define INCLUDED_EVENTHANDLER_

#include "event.h"
#include "coreexceptions.h"
#include "eventexpression.h"
#include <functional>
#include <string>
#include <vector>
#include <memory>
#include <set>

namespace dynaa {

/**
 * EventHandler
 *
 */
class EventHandler {

private:
    /**
    * A generator for unique identifiers of event handlers
    */
    static long m_handlerSequenceNumber;

    /**
     * An identifier for print outs of this event handler.
     */
    const std::string identifier;

protected:

    /**
     * An identifier for this event handler
     */
    const long id;

    /**
     * The callback function associated with this event handler.
     */
    const std::function<void(Event)> m_eventCallback;

    // NOTE this is now stored by the registry, because an event handler can be used
    // for multiple wait calls
    /**
     * A flag to indicate that this event handler is to be triggered only once
     */
    //bool once = false;

    /**
     * The priority level for this event handler. Range 1 - 10 : 1 is more urgent.
     */
    const int priority;

    /**
     * A list of weak pointers to be used as safe_guards for calling the handle.
     */
    const std::vector<std::weak_ptr<Entity>> safe_guards;

    static bool safeCheck(std::weak_ptr<Entity> safe_guard);

public:
    static std::shared_ptr<EventHandler> create(std::function<void(Event)> f);
    static std::shared_ptr<EventHandler> create(std::function<void(Event)> f, int priority);
    static std::shared_ptr<EventHandler> create(std::function<void(Event)> f, std::string identifier);
    static std::shared_ptr<EventHandler> create(std::function<void(Event)> f, std::string identifier, int priority);
    static std::shared_ptr<EventHandler> create(std::function<void(Event)> f, std::string identifier,
            std::vector<std::weak_ptr<Entity>> safe_guards);
    static std::shared_ptr<EventHandler> create(std::function<void(Event)> f, std::string identifier,
            std::vector<std::weak_ptr<Entity>> safe_guards, int priority);
    static std::shared_ptr<EventHandler> create(std::function<void(Event)>, std::vector<std::weak_ptr<Entity>> safe_guards);
    static std::shared_ptr<EventHandler> create(std::function<void(Event)>, std::vector<std::weak_ptr<Entity>> safe_guards,
            int priority);

    static const int DEFAULT_PRIORITY_LEVEL;
    static const int HIGHEST_PRIORITY_LEVEL;
    static const int LOWEST_PRIORITY_LEVEL;

    /**
     * Constructor
     */
    EventHandler(std::function<void(Event)> f, std::string identifier,
                 std::vector<std::weak_ptr<Entity>> safe_guards, int priority) :
            identifier(identifier),
            id(EventHandler::m_handlerSequenceNumber++),
            m_eventCallback(f),
            priority(priority),
            safe_guards(safe_guards) {
        if ((priority < HIGHEST_PRIORITY_LEVEL) || (priority > LOWEST_PRIORITY_LEVEL)) {
            throw InvalidEventHandlerPriority();
        }
    }

    /**
     * Constructor
     */
    EventHandler(std::function<void(Event)> f, std::string the_identifier) :
        EventHandler(f, the_identifier, {}, DEFAULT_PRIORITY_LEVEL) {}

    /**
     * Constructor
     */
    EventHandler(std::function<void(Event)> f, std::string the_identifier, int the_priority) :
        EventHandler(f, the_identifier, {}, the_priority) {}

    /**
     * Constructor
     */
    EventHandler(std::function<void(Event)> f) :
        EventHandler(f, DEFAULT_PRIORITY_LEVEL) {};

    /**
     * Constructor
     */
    EventHandler(std::function<void(Event)> f, int the_priority) :
        EventHandler(f,"_", the_priority) {}

    /**
     * Constructor
     */
    EventHandler(std::function<void(Event)> f, std::vector<std::weak_ptr<Entity>> the_safe_guards) :
        EventHandler(f, "_", the_safe_guards, DEFAULT_PRIORITY_LEVEL) {}
    /**
     * Constructor
     */
    EventHandler(std::function<void(Event)> f, std::vector<std::weak_ptr<Entity>> the_safe_guards, int the_priority) :
        EventHandler(f, "_", the_safe_guards, the_priority) {}

    /**
    * Constructor
    */
    EventHandler(std::function<void(Event)> f, std::string the_identifier,
                 std::vector<std::weak_ptr<Entity>> the_safe_guards) :
        EventHandler(f, the_identifier, the_safe_guards, DEFAULT_PRIORITY_LEVEL) {}

    /**
     * Default Constructor
     *
     * Has no callback function.
     */
    EventHandler() :
            //m_eventCallback(nullptr),
            identifier("_"),
            id(EventHandler::m_handlerSequenceNumber++),
            priority(DEFAULT_PRIORITY_LEVEL),
            safe_guards({}) {}
   
    /**
     * Copy constructor
     */
    EventHandler(const EventHandler& eventHandler) :
            identifier(eventHandler.identifier),
            id(eventHandler.id),
            m_eventCallback(eventHandler.m_eventCallback),
            priority(eventHandler.priority),
            safe_guards(eventHandler.safe_guards) {}

    /**
     * Destructor
     */
    ~EventHandler() {}

    /**
    * Handles the event.
    *
    * @param event
    *            the event that triggered this handle.
    */
    void handle(Event event);

    /**
     * Get the identifier of the event handler in a way that makes human
     * interpretation possible
     *
     * @return A identifier for human interpretation
     */
    const std::string getIdentifier();

    /**
     * Informs if this handler is one shot triggered. Called only once
     */
    // TODO 'once' should be held by registry not event handlers!
    //bool isOnce() const;

    /**
     * Set whether this is a one shot handler.
     *
     * @param value
     *     Whether to only trigger this handler once.
     */
    //void setOnce(bool value) {
    //    // TODO 'once' should be held by registry not event handlers!
    //    once = value;
    //};

    /**
     * Retrieves the priority level of this event handler
     */
    int getPriorityLevel() const;

    /*
    * Used for comparison of event handlers in maps and sets
    */
    bool operator<(const EventHandler &other) const;
};

}

#endif
