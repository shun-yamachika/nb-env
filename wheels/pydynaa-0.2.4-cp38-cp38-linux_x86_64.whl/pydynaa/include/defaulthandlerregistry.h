/**
 * File defaulthandlerregistry.h
 */

#ifndef INCLUDED_DEFAULTHANDLERREGISTRY_
#define INCLUDED_DEFAULTHANDLERREGISTRY_

#include "event.h"
#include "eventtype.h"
#include "eventhandler.h"
#include "eventexpression.h"
#include "expressionhandler.h"
#include "handlerregistrationinterface.h"
#include "handlerqueryinterface.h"
#include <memory>
#include <unordered_map>
#include <set>

namespace dynaa {

/**
 * DefaultHandlerRegistry
 */
class DefaultHandlerRegistry : public HandlerRegistrationInterface, public HandlerQueryInterface {

private:

    static const long defaultIDMask;

    /**
     * EventMask is an internal type used as key in the mappings between event observers and events.
     *
     * An event handler is triggered when an event in the system matches its event mask.
     *
     * Developer documentation:
     *
     * The implementation of EventMask is done to be a straightforward data struct of 3 longs.
     * The intention is to keep it extremely simple for performance. Typical operations are
     * comparison, hashing, and matches (cover).
     *
     * In this implementation the value 0xFFFFFFFFFFFF for a field is used as a wildcard symbol,
     * instead of an absolute field value.  Whereas this value is used, it will match (or cover)
     * any other absolute value.
     */
    struct EventMask {
        long sourceID;
        long typeID;
        EventID eventID;

        /**
         * Equality operator for an event mask
         *
         * An event mask is considered to be equal, when all its fields(sourceID, typeID, and eventID)
         * are equal
         */
        bool operator==(const EventMask &other) const;

        /**
         * Checks if the event mask matches another masked event.
         *
         * An event mask matches its masked event if each field of the mask (sourceID, typeID, eventID)
         * matches its equivalent field in the masked event.
         *
         * @param mask the mask against which the match is tested
         * @param masked the event mask to be tested against the mask
         *
         * @return true is the event mask matches the masked event
         */
        static inline bool matches(const EventMask &mask,
                                   const EventMask &masked);

        /**
         * Checks if a mask matches the masked field
         *
         * A mask matches the masked field if :
         *
         *  - the mask field is default (0xFFFFFFFFFFFFFFFF); or
         *
         *  - the mask field is equal to the masked field;
         *
         * @param mask the mask field to be checked against
         * @param masked the field to check against the mask
         *
         * @return  true if fields match, false otherwise.
         */
        static inline bool matches(const long mask, const long masked);

        /**
         * Hash operator for this event mask. Hashing is important for using event masks as keys in the
         * registry
         */
        size_t operator()(const EventMask &k) const;
    };

    /**
     * A map to hold the registration of event handlers
     *
     * It is an onordered_map because we make a lot of operations by key.
     */
    std::unordered_map<const EventMask, HandlerSet, EventMask> handlerMap;

    /**
     * Maps to hold data related to the registration of expression handlers
     */
    std::unordered_map<std::shared_ptr<EventExpression>, ExpressionHandlerSet> exprHandlerMap;
    std::unordered_map<std::shared_ptr<EventExpression>, std::vector<std::weak_ptr<EventHandler>>> atomicHandlerMap;

public:
    /**
     * The constructor of the DefaultHanlderRegistry sets up the handler maps
     */
    DefaultHandlerRegistry() : handlerMap(), exprHandlerMap(), atomicHandlerMap() {};

    /*
     * @see
     * HandlerQueryInterface#getEventHandlersOf
     */
    HandlerSet getEventHandlersOf(const Event &event) override;

    /*
     * @see
     * HandlerQueryInterface#getEventHandlersOf
     */
    ExpressionHandlerSet getExpressionHandlersOf(const std::shared_ptr<EventExpression>& evExpr) const override;

    /*
     * @see
     * HandlerQueryInterface#getNumberOfHandlers
     */
    long int getNumberOfHandlers() const override;

    /*
     * @see
     * HandlerRegistryInterface#registerHandler
     */
    void registerHandler(std::shared_ptr<EventHandler> eventHandler,
                         const EventSource entity,
                         const EventType &eventType,
                         const EventID id,
                         const bool once) override;

    /*
     * @see
     * HandlerRegistryInterface#unregisterHandler
     */
    void unregisterHandler(std::shared_ptr<EventHandler> eventHandler,
                           const EventSource entity,
                           const EventType &eventType,
                           const EventID id) override;

    /*
     * @see
     * HandlerRegistryInterface#registerHandler
     */
    void registerHandler(std::shared_ptr<ExpressionHandler> expressionHandler,
                         std::shared_ptr<EventExpression> evExpr, bool once, bool reprime=true) override;

    /*
     * @see
     * HandlerRegistryInterface#unregisterHandler
     */
    void unregisterHandler(const std::shared_ptr<ExpressionHandler>& expressionHandler,
                           const std::shared_ptr<EventExpression>& evExpr) override;


    /**
     * Resets this registry.
     *
     * Deletes all entries in the internal registry and empties it.
     *
     */
    void reset();

private:
    /**
     * Concatenate a Set of EventHandlers to include a (new) Set of handlers to
     * be fetched from the handlerMap
     *
     * @param observers
     *            the already existing Set of EventHandlers. May include
     *            EventHandlers already, and these will stay in it.
     * @param source
     *            the triggering entity source of the handlers to add
     * @param type
     *            the triggering event type of the handlers to add
     * @param id
     *            the triggering event id of the handlers to add
     * @return a Set of EventHandlers which is a copy of the first input
     *         argument, with new handlers added
     */
    void appendHandlersTo(HandlerSet * const handlers, const EventSource source, const EventType &type,
                          const EventID id);

    /**
     * Function to generate the lookup key used for the handlerMap
     *
     * @param source
     *            the Entity that is the source of the event
     * @param type
     *            the EventType of the event
     * @param id
     *            the unique identifier of the event
     * @return a String which is a unique identifier for this event handler
     */
    static const EventMask generateMask(const EventSource source, const EventType &type, const EventID id);

    /**
     * Register event handlers for atomic expressions.
     * Used internally.
     */
    void registerAtomicHandlers(
            const std::shared_ptr<EventExpression>& parentExpr,
            const std::shared_ptr<EventExpression>& evExpr, int priority);
    /**
     * Unregister event handlers for atomic expressions.
     * Used internally.
     */
    void unregisterAtomicHandlers(const std::shared_ptr<EventExpression>& evExpr);

    /**
     * Trigger an atomic event expression.
     *
     * @param expressionHandler
     *            expression handler waiting on parent event expression.
     * @param parentExpr
     *            parent event expression of atomic event expression.
     * @param atomicExpr
     *            atomic event expression that triggered.
     * @param event
     *            the event that triggered this handle.
     *
     */
    void triggerAtomicExpression(
            std::weak_ptr<EventExpression> parentExpr,
            std::weak_ptr<EventExpression> atomicExpr, Event event);

};
}

/**
 * DISCUSSIONS AND DECISIONS
 *
 * Design of DefaultHandlerRegistry
 *
 * 1) Atomic expression handlers for registered EventExpressions
 *
 * When a (composite) EventExpression is registered (with an ExpressionHandler) for the first time,
 * internal EventHandler objects are registered for each atomic expression. These "atomic handlers"
 * are stored in a vector of weak pointers. Their callbacks will set the triggered event of the atomic
 * expression and check if the registered (super-parent) expression is triggered.
 *
 * 2) RegisteredHandler
 *
 * The `HandlerSet` is modified to be an ordered set of `RegisteredHandler<EventHandler>`,
 * so that the 'once' boolean flag is managed by the registry rather than being a private attribute of EventHandlers. This means event handlers can be consistently used in multiple different calls to wait (it was the case that re-using an event handler could incorrectly change its previous 'once' value).
 *
 *
 */


#endif
