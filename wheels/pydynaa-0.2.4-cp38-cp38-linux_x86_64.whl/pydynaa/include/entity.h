/*
file: entity.h
authors: Julio Oliveira

Definition of the Entity class
*/

#ifndef INCLUDED_ENTITY_
#define INCLUDED_ENTITY_

#include "dynaatypes.h"
#include "eventtype.h"
#include "event.h"
#include "eventhandler.h"
#include "expressionhandler.h"
#include "scheduleruserinterface.h"
#include "simengine.h"
#include "eventexpression.h"
#include <string>
#include <iostream>
#include <memory>

//class HandlerRegistrationInterface; // forward declaration

namespace dynaa {
/**
 * Core class for a simulation entity
 *
 * This class designs the basic behavior of an entity in the Dynaa simulation
 * system.
 *
 */
class Entity : public std::enable_shared_from_this<Entity> {

private:
    /**
      * Seed for identifier sequences
      */
    static long m_idseed;

    /**
      * Entity unique identifier
      */
    const long m_uid;

public:
    /**
      * Prefix for entity print outs
      */
    static const std::string ENTITY_PREFIX;

    /**
       * Default constructor for Entity.
       */
    Entity() : m_uid(Entity::m_idseed++),
        hRegistry(SimulationEngine::getInstance().getHandlerRegistry()),
        scheduler(SimulationEngine::getInstance().getScheduler()) {};

    /**
       * Retrieves a unique ID for this Entity.
       *
       * @return an unique ID for this entity.
       */
    long getUID() const;

    /**
    * Comparison operator (equality)
    *
    * @return true if entities have the same unique id
    */
    bool operator==(const Entity &other) const;
    /**
    * Comparison operator (inequality)
    *
    * @return true if entities are unequal (see operator==), false otherwise
    */
    bool operator!=(const Entity &other) const;

    friend std::ostream &operator<<(std::ostream &strm, const Entity &entity);

protected:
    HandlerRegistrationInterface& hRegistry;
    SchedulerUserInterface& scheduler;

    void dismiss(std::shared_ptr<EventHandler> eventHandler) ;
    void dismiss(std::shared_ptr<EventHandler> eventHandler, const EventSource source) ;
    void dismiss(std::shared_ptr<EventHandler> eventHandler, const EventType &type) ;
    void dismiss(std::shared_ptr<EventHandler> eventHandler, const Event &event) ;
    void dismiss(std::shared_ptr<EventHandler> eventHandler, const EventSource source, const EventType &type) ;
    void dismiss(std::shared_ptr<EventHandler> eventHandler, const EventSource source, const EventType &type,
                 const EventID id);
    void dismiss(std::shared_ptr<EventHandler> eventHandler, const EventType &evType, const EventID id);
    void dismiss(const std::shared_ptr<ExpressionHandler>& expressionHandler,
                 const std::shared_ptr<EventExpression>& eventExpression);
    void dismiss(const std::shared_ptr<ExpressionHandler>& expressionHandler);

    /**
     * Creates an event with the indicated type and with this entity as source,
     * and schedules it after the designated interval.
     *
     * @param interval
     *            time after which (in relation to current simulation time) the
     *            event will be scheduled.
     * @param type
     *            the type of the event to be generated.
     * @return the scheduled event.
     * @throws InvalidTimepointException
     *             if interval is negative.
     */
    Event scheduleAfter(SimTime interval, const EventType& type);
    Event scheduleAfter(SimTime interval, const std::shared_ptr<EventType>& type);

    /**
     * Creates an event with the indicated type and with this entity as source,
     * and schedules it at the designated time point.
     *
     * Indicated time point must be after or equal to the current simulation
     * time.
     *
     * @param timepoint
     *            time at which the event will be scheduled. Must be larger or
     *            equal to current time.
     * @param type
     *            the type of the event to be generated.
     * @return the scheduled event.
     * @throws InvalidTimepointException
     *             if time point is before the simulation current time
     */
    Event scheduleAt(SimTime instant, const EventType &type);
    Event scheduleAt(SimTime instant, const std::shared_ptr<EventType>& type);

    /**
     * Creates an event with the indicated type and with this entity as source,
     * and schedules it at the current simulation time.
     *
     * @param type
     *            the type of the event to be generated.
     * @return the scheduled event.
     */
    Event scheduleNow(const EventType &type);
    Event scheduleNow(const std::shared_ptr<EventType>& type);

    /**
       * Makes the event handler an observer of any future event, independent of
       * the event's source, type, or id.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @throws InvalidEventHandlerException
       *             If event handler is null.
       */
    void wait(std::shared_ptr<EventHandler> eventHandler) const;

    /**
       * Makes the event handler an observer of any future event that comes from
       * the given source, independent of its type, or id.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param source
       *            the source of the event to be observed. Must be non-null.
       * @throws InvalidEventException
       * @throws InvalidEventHandlerException
       *             If event handler is null.
       */
    void wait(std::shared_ptr<EventHandler> eventHandler, const EventSource source) const;

    /**
       * Makes the event handler an observer of any future event of the indicated
       * type and with the indicated id, independent of its source.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param id
       *            the id of the event to be observed.
       * @param type
       *            the type of the event to be observed.
       * @throws InvalidEventException
       * @throws InvalidEventHandlerException
       */
    void wait(std::shared_ptr<EventHandler> eventHandler, const EventType &type, const EventID id) const;

    /**
       * Makes the event handler an observer of any future event of the indicated
       * type that comes from the given source, independent of its id.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param source
       *            the source of the event to be observed.
       * @param type
       *            the type of the event to be observed.
       * @throws InvalidEventException
       * @throws InvalidEventHandlerException
       */
    void wait(std::shared_ptr<EventHandler> eventHandler, const EventSource source, const EventType &type) const;

    /**
       * Makes the event handler an observer of any future event of the indicated
       * type that comes from the given source, independent of its id.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param source
       *            the source of the event to be observed.
       * @param type
       *            the type of the event to be observed.
       * @param id
       *            the id of the event to be observed.
       * @throws InvalidEventException
       * @throws InvalidEventHandlerException
       */
    void wait(std::shared_ptr<EventHandler> eventHandler, const EventSource entity,
              const EventType &evType, const EventID id) const;

    /**
       * Makes the event handler an observer of any future event of the indicated
       * type independent from its source and id.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param type
       *            the type of the event to be observed.
       * @throws InvalidEventHandlerException
       *             If event handler is null.
       * @throws InvalidEventException
       *
       **/
    void wait(std::shared_ptr<EventHandler> eventHandler, const EventType &type) const;

    /**
       * Makes the event handler an observer of any future event of the indicated
       * id independent of its source or type.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param id
       *            the id of the event to be observed
       *
       **/
    void wait(std::shared_ptr<EventHandler> eventHandler, const EventID id) const;

    /**
       * Makes the event handler an observer of any future event from the
       * indicated source and with the indicated id, independent of its type.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param source
       *            the source of the event to be observed.
       * @param id
       *            the id of the event to be observed.
       * @throws InvalidEventHandlerException
       *             If event handler is null.
       * @throws InvalidEventSourceException
       *             If source is null
       * @throws InvalidEventIdException
       *             If id is negative or zero.
       * @throws InvalidEventException
       *             If invalid parameter.
       *
       **/
    void wait(std::shared_ptr<EventHandler> eventHandler, const EventSource source, const EventID id) const;

    /**
       * Makes the expression handler an observer of any future triggering of
       * the event expression.
       *
       * After the expression triggers it will immediately be re-primed to trigger again.
       *
       * @param expressionHandler
       *            the observer to be triggered when the event expression occurs.
       * @param eventExpression
       *            the event expression to observe.
       *
       */
    void wait(std::shared_ptr<ExpressionHandler> expressionHandler, std::shared_ptr<EventExpression> evExpr) const;

    /**
       * Makes the event handler an observer of next future event of the indicated
       * type independent from its source and id.
       *
       * Only the next matching event will trigger the event handler. After that,
       * the handler will be automatically dismissed.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param type
       *            the type of the event to be observed.
       * @throws InvalidEventHandlerException
       *             If event handler is null.
       * @throws InvalidEventException
       *
       **/
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const EventType &type) const;

    /**
       * Makes the event handler an observer of the next future event of the
       * indicated type that comes from the given source, independent of its id.
       *
       * Only the next matching event will trigger the event handler. After that,
       * the handler will be automatically dismissed.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param source
       *            the source of the event to be observed.
       * @param type
       *            the type of the event to be observed.
       * @throws InvalidEventException
       * @throws InvalidEventHandlerException
       */
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const EventSource source, const EventType &type) const;

    /**
       * Makes the event handler an observer of next future event that comes from
       * the given source, independent of its type, or id.
       *
       * Only the next matching event will trigger the event handler. After that,
       * the handler will be automatically dismissed.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param source
       *            the source of the event to be observed. Must be non-null.
       * @throws InvalidEventException
       * @throws InvalidEventHandlerException
       *             If event handler is null.
       */
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const EventSource source) const;

    /**
       * Makes the event handler an observer of the next future event of the
       * indicated type and with the indicated id, independent of its source.
       *
       * Only the next matching event will trigger the event handler. After that,
       * the handler will be automatically dismissed.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param id
       *            the id of the event to be observed.
       * @param type
       *            the type of the event to be observed.
       * @throws InvalidEventException
       * @throws InvalidEventHandlerException
       */
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const EventType &type, const EventID id) const;

    /**
       * Makes the event handler an observer of the indicated event.
       *
       * Only the next matching event will trigger the event handler. After that,
       * the handler will be automatically dismissed.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param event
       *            the specific event that will trigger the handler
       * @throws InvalidEventException
       * @throws InvalidEventHandlerException
       */
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const Event &event) const;

    /**
       * Makes the event handler an observer of next future event of the indicated
       * id independent of its source or type.
       *
       * Only the next matching event will trigger the event handler. After that,
       * the handler will be automatically dismissed.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param id
       *            the id of the event to be observed
       *
       **/
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const EventID id) const;

    /**
       * Makes the event handler an observer of next future event, independent of
       * the event's source, type, or id.
       *
       * Only the next matching event will trigger the event handler. After that,
       * the handler will be automatically dismissed.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @throws InvalidEventHandlerException
       *             If event handler is null.
       */
    void waitOnce(std::shared_ptr<EventHandler> eventHandler) const;

    /**
       * Makes the event handler an observer of the next future event from the
       * indicated source and with the indicated id, independent of its type.
       *
       * Only the next matching event will trigger the event handler. After that,
       * the handler will be automatically dismissed.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param source
       *            the source of the event to be observed.
       * @param id
       *            the id of the event to be observed.
       * @throws InvalidEventHandlerException
       *             If event handler is null.
       * @throws InvalidEventSourceException
       *             If source is null
       * @throws InvalidEventIdException
       *             If id is negative or zero.
       * @throws InvalidEventException
       *             If invalid parameter.
       *
       **/
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const EventSource source, const EventID id) const;

    /**
       * Makes the event handler an observer of the next future event of the
       * indicated type that comes from the given source, and with the given id.
       *
       * Only the next matching event will trigger the event handler. After that,
       * the handler will be automatically dismissed.
       *
       * @param eventHandler
       *            the observer to be triggered when a matching event occurs.
       * @param source
       *            the source of the event to be observed.
       * @param type
       *            the type of the event to be observed.
       * @param id
       *            the id of the event to be observed.
       * @throws InvalidEventException
       * @throws InvalidEventHandlerException
       */
    void waitOnce(std::shared_ptr<EventHandler> eventHandler, const EventSource source, const EventType &type,
                  const EventID id) const;

    /**
       * Makes the expression handler an observer of the next future triggering of
       * the event expression.
       *
       * Only the next trigger of the event expression will trigger the expression handler.
       * After that the expression handler will be automatically dismissed.
       *
       * @param expressionHandler
       *            the observer to be triggered when the event expression occurs.
       * @param eventExpression
       *            the event expression to observe.
       *
       */
    void waitOnce(std::shared_ptr<ExpressionHandler> expressionHandler,
                  std::shared_ptr<EventExpression> eventExpression) const;

private:
    /**
    * Effective method to be called by all other dismiss interface methods.
    */
    void dismissHandler(std::shared_ptr<EventHandler> eventHandler, const EventSource source, const EventType &type,
                        const EventID id) ;

    /**
    * Effective method to be called by all other wait interface methods.
    */
    void waitOnEvent(std::shared_ptr<EventHandler> eventHandler, const EventSource source, const EventType &eventType,
                     const EventID id,
                     const bool once) const;
};

/**
* Overloads the << operator
*/
std::ostream &operator<<(std::ostream &strm, const Entity &entity);
}
#endif
