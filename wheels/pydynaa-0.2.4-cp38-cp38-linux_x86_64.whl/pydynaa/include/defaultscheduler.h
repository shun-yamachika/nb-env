/*
file: scheduler.h
author: Julio Oliveira, TNO

definition of class Scheduler
*/

#ifndef INCLUDED_SCHEDULER_
#define INCLUDED_SCHEDULER_

#include <map>
#include <vector>

#include "dynaatypes.h"
#include "schedulerinspectorinterface.h"
#include "scheduleruserinterface.h"

namespace dynaa {

/**
 * Core class offering a default scheduler implementation for cDynAA
 *
 * The DefaultScheduler is offers a facade to
 *
 */
class DefaultScheduler :  virtual public SchedulerInspectorInterface,  virtual public SchedulerUserInterface {

    typedef std::map<SimTime, EventSet> Timeline;

private:

    Timeline m_timeline;

public:
    /**
    *  Default inlined constructor
    */
    DefaultScheduler() : m_timeline() {}

    void scheduleNow(const Event event);
    void scheduleAt(SimTime instant, const Event event);
    void scheduleAfter(SimTime interval, const Event event);
    void unschedule(const Event event);
    SimTime getNextInstant() const;
    EventSet removeEventsAt(const SimTime instant);
    EventSet getEventsAt(const SimTime instant) const;
    std::vector<SimTime> getInstants() const;
    long getNumberOfInstants() const;
    long getNumberOfEvents() const;
    void reset();
};
}

#endif
