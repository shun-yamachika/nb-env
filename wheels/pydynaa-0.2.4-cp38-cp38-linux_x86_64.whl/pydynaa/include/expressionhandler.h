/**
 * File expressionhandler.h
 */
#ifndef INCLUDED_EXPRESSIONHANDLER_
#define INCLUDED_EXPRESSIONHANDLER_

#include "event.h"
#include "coreexceptions.h"
#include "eventhandler.h"
#include "eventexpression.h"
#include <functional>
#include <vector>
#include <memory>
#include <algorithm>
#include <set>

namespace dynaa {

/**
 * ExpressionHandler
 *
 */
class ExpressionHandler: public EventHandler {

private:
    /**
     * The callback function associated with this event handler, if applicable.
     */
    const std::function<void(std::shared_ptr<EventExpression>)> m_exprCallback;

public:

    /**
     * Constructors for a handler using a callback function expecting an event expression.
     *
     * This is for standard usage of event expressions.
     */
    ExpressionHandler(std::function<void(std::shared_ptr<EventExpression>)> f, std::string identifier,
                      std::vector<std::weak_ptr<Entity>> safe_guards, int priority) :
            EventHandler(nullptr, identifier, safe_guards, priority), m_exprCallback(f) {}
    ExpressionHandler(std::function<void(std::shared_ptr<EventExpression>)> f, std::string identifier,
                      std::vector<std::weak_ptr<Entity>> safe_guards) :
            ExpressionHandler(f, identifier, safe_guards, DEFAULT_PRIORITY_LEVEL) {}
    ExpressionHandler(std::function<void(std::shared_ptr<EventExpression>)> f, std::string identifier, int priority) :
            ExpressionHandler(f, identifier, {}, priority) {}
    ExpressionHandler(std::function<void(std::shared_ptr<EventExpression>)> f, std::string identifier) :
            ExpressionHandler(f, identifier, {}, DEFAULT_PRIORITY_LEVEL) {}

    /**
     * Constructor for a handler using a callback function expecting an event.
     *
     * This is for legacy support of existing callback functions. Recommended to only be used
     * with atomic event expressions.
     *
     */
    //ExpressionHandler(function<void(Event)> f, std::string identifier = "_",
    //                  std::vector<std::weak_ptr<Entity>> safe_guards = {}, int priority = DEFAULT_PRIORITY_LEVEL) :
    //        EventHandler(f, identifier, safe_guards, priority),
    //        m_exprCallback(nullptr) {};

    /**
     * Constructor for a handler with no callback.
     *
     * This is for legacy support of event expression that take no callback function.
     *
     */
    ExpressionHandler(std::string identifier, std::vector<std::weak_ptr<Entity>> safe_guards, int priority) :
            EventHandler(nullptr, identifier, safe_guards, priority) {}

    /**
     * Default Constructor
     *
     * Has no callback function.
     */
    ExpressionHandler() : EventHandler() {};

    /**
     * Copy Constructor
     */
    ExpressionHandler(const ExpressionHandler& exprHandler) :
            EventHandler(exprHandler),
            m_exprCallback(exprHandler.m_exprCallback) {}

    /**
     * Default Destructor
     */
    ~ExpressionHandler() {}

    /**
     * Handles the event.
     *
     * @param event
     *            the event that triggered this handle.
     */
    void handle(Event event);

    /**
     * Handles the event expression.
     *
     * @param eventExpression
     *            the event expression that triggered this handle.
     */
    void handle(std::shared_ptr<EventExpression> eventExpression) const;

    /**
     * Compare two event expressions.
     *
     * @param exprHandler
     *            the expression handler to compare with.
     */
    bool operator< (const ExpressionHandler& exprHandler) const;
};

}

#endif
