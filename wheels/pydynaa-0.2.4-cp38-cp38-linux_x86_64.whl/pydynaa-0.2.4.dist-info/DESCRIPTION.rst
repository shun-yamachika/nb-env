cDynAA/pyDynAA discrete event simulation engine
===============================================

Description
-----------

*cDynAA* is the C++ port of the [DynAA](https://ci.tno.nl/gitlab/DynAA/DynAA) core layer.
Like the java core of DynAA, it is the base simulation engine for several other domain specific simulators, each of which includes a specific *model layer*.

*pyDynAA* is a Python wrapper around the C++ DynAA core.
The wrapping is done using Cython and supports event handler callback functions in pure Python, as well as in Cython.
Because the pyDynAA package includes Cython definitions of the core classes (Event, Entity, etc.), a model layer using pyDynAA can itself (optionally) implement speed critical components in Cython.

pyDynAA is currently used in the [NetSquid quantum 
network simulator](https://netsquid.org) project, a collaboration between TNO and the QuTech [QINC](https://qutech.nl/roadmap/quantum-internet/) group.

Installation
------------

Here we describe how to install the pyDynAA package as a user.
If you are a developer wanting to build and install pyDynAA or the cDynAA C++ library from source then see the [INSTALL.md](INSTALL.md) file.

The prerequisites for the user installation of pyDynAA are:
- A modern Linux or MacOS 64-bit (x86_64) operating system. If you don't have linux you could run it via virtualization, e.g. using [VirtualBox](https://www.virtualbox.org/). If you have Windows 10 you can also use the [Bash on Ubuntu](https://www.howtogeek.com/249966/how-to-install-and-use-the-linux-bash-shell-on-windows-10/) subsystem.
- Python version 3.5 or higher.
- The python package install [pip](https://pip.pypa.io/en/stable/) version 19 or higher. To upgrade your current pip version run `pip3 install --upgrade pip`.
- The Python package _cysignals_.

### Installing using a PyPI server

PyDynAA can be installed by pointing the [Python _pip_ installer](https://pip.pypa.io/en/stable/user_guide/#user-installs) to NetSquid's private [python package index](https://pypi.org/) server.
To access this server you need a valid _username_ and _password_: please [contact us](https://netsquid.org/contact) if you do not.

To install the Netsquid python package run the following command from a terminal:
```
pip3 install --user --extra-index-url https://<username>:<password>@pypi.netsquid.org pydynaa
```
substituting the correct values for `<username>` and `<password>`.
To install the package system-wide (for all users) remove the `--user` argument.

### Installing using a wheel file

If you have received a binary wheel distribution (`.whl` file) of pyDynAA it is important that your system's architecture, operating system, and major Python version  match that of the file.
For example, the file `pydynaa-0.1.0-cp36m-linux_x86_64.whl` is intended for a linux OS running on a 64 bit architecture with Python 3.6 (i.e. cp36m).

This file can be installed using the [Python _pip_ installer](https://pip.pypa.io/en/stable/user_guide/#user-installs). For example, to install locally as a user run:
```
pip3 install --user pydynaa-0.1.0-cp36m-linux_x86_64.whl
```
To install the package system-wide (for all users) remove the `--user` argument.

License
-------

Copyright (C) 2017-2019 TNO (Julio de Oliveira Filho, Rob Knegjens, Coen van Leeuwen).

License TBD (currently all rights reserved).


CHANGELOG
=========

**Important**: if pyDynAA or cDynAA fails to build or the tests fail, try cleaning the building environment before building again e.g.:
```
make clean
make && make tests
```
This will clean up any lingering object or library files (.o, .so, etc.) that may be causing problems.

For details concerning new features please refer to documentation, which can be built locally with `make docs`.

2019-02-05 Rob
--------------

- In cDynAA `EventExpression` has added methods `atomicEventType()`, `atomicEventID()`, `atomicEventSource()`, which replace `atomicEventMask()`.
- In pyDynAA `EventExpression` has the added properties `atomic_type`, `atomic_id` and `atomic_source`.

2019-12-13 Rob
--------------

- Added `EventExpression.triggered_events()` method in pyDynA which gives a sorted list of all triggered events. Deprecates `EventExpression.triggered_event` method.

2019-12-11 Rob
--------------

- Added support for `EventExpression.reprime()` method in pyDynAA.

2019-12-06 Rob
--------------

The use of event expressions has been redesigned in both cDynAA and pyDynAA. Changes to the public interfaces include:

- EventExpressions are _waited_ on by entities using a handler object in the same way events are waited for. Continuous wait is now also supported. For example, in pyDynAA one can do `entity._wait{_once}(handler, expression=evexpr)`.
- Event expression handlers can similarly be _dismissed_ e.g. as `Entity._dismiss(handler, expression=evexpr)` or `Entity._dismiss(handler)`.
- An `ExpressionHandler` object can be used to wait on event expressions, which is a subclass of EventHandler with the same properties e.g. priority, safe guards, etc. The callback function used to initialise the handler takes an EventExpression object as its only parameter.
- When an _atomic_ EventExpression is triggered it stores a copy of the event that triggered it. This way a user can determine from the event expressions given by a callback function what the sources and types of the events were that triggered the atomic expressions.
- An EventExpression object can be _waited_ on by multiple handlers, which will be executed in order of priority. By default a new call to wait will reset an event expression i.e. re-prime all its triggered atomic expressions. Atomic expressions are waited on using the highest priority of the waiting set of handlers.
- An ExpressionHandler object can be used in different calls to wait i.e. it is independent of the EventExpression(s) it is asked to wait for.
- Shared pointers to EventExpressions and ExpressionHandlers are stored in the handler registry until they are dismissed. That means there are no memory issues if the user relinquishes their owernship e.g. lets them leave scope.
- Support for copying of EventExpression in pydynaa, including a `copy()` method.
- SimulationEngine in cdynaa has methods to get the inspector interfaces of the simulation scheduler and registry.
- SimulationEngine in pydynaa has a `get_expression_handlers` method.

Modified and removed/deprecated existing functionality:

- If the event expression `A = B | C` is triggered due to `B` while `C` was also due to trigger at the same instant, then `C` will no longer be triggered in this expression. If a handler is waiting continuously on this expression, then the expression is reset and triggered again for `C` (at which point `B` is no longer triggered).
- EventExpression has its `wait(callback)` and `wait()` methods removed (cDynAA) or deprecated (pyDynAA).
- EventExpression is no longer a sub-class of Entity.
- The handler registry class (used by SimulationEngine to reigster EventHandlers per event mask) can also (un)register ExpressionHandler objects. These handlers are registered to wait per `EventExpression` object (both are managed by shared pointers)
- `RegisteredHandler<T>` is a C++ template consisting of a `shared_ptr<T>` and a boolean 'once' value, where T can be an EventHandler or an ExpressionHandler. The boolean indicates whether the handler in single shot (once) or not. The `RegisteredHandler<T>` objects is ordered in a set using the handlers priority (see the `operator<` method).
- The `HandlerSet` in cDynAA is modified to be an ordered set of `RegisteredHandler<EventHandler>`, so that the 'once' boolean flag is managed by the registry rather than being a private attribute of EventHandlers. This means event handlers can be consistently used in multiple different calls to wait (it was the case that re-using an event handler could incorrectly change its previous 'once' value).


2019-11-28 Rob
--------------

- Event in cdynaa privately stores its type (EventType) internally using a shared pointer to avoid copying of EventType object everytime Event is passed by value. This also fixes a longstanding bug in MacOS.
- The constructor of Event and the `Entity.schedule{Now,After,At}` methods are overloaded in cdynaa to support also passing of an existing shared pointer of EventTypes.

2019-11-18 Rob
--------------

- Added support for Python 3.8 to CI pipeline.
- Version module also finds version tags not in direct history of the current branch.

2019-11-05 Rob
--------------

- Moved `version.py` out of _pydynaa_ package into repository root directory.
- The version is now automatically calculated from the latest version tag in the Git branch's history. If HEAD is ahead of the last version tag `vX.Y.Z` by `N > 0` commits, then the is version bumped up to the development version: `vX.Y.{Z+1}.dev{N-1}+{commit hash}`.
- The package version is now automatically stored in generated `pydynaa/version.txt` file (untracked).

2019-10-28 Rob
--------------

- Support for versioning and binary packaging of pyDynAA.
- Repository housekeeping, including creation of this file.
- Support for deploying binary package, also via CI pipeline.


